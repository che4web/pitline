from django.apps import AppConfig


class actionConfig(AppConfig):
    name = 'action'
