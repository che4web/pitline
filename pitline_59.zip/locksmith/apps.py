from django.apps import AppConfig


class locksmithConfig(AppConfig):
    name = 'locksmith'
